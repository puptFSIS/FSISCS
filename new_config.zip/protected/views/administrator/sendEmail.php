<?php
	include_once ("config.php");
	require ('phpmailer/PHPMailerAutoload.php');

	$subject = $_POST['subject'];
	$message = $_POST['message'];
	$message .= '<br><br><br>Click <a href="http://pup-taguig.net/FSISCS">http://pup-taguig.net/FSISCS</a> to visit our website.';

	$recipients = array();

	$currMonth = date('n');
	$currYear = date('Y');

	if($currMonth < 6) {
		$currSchoolYear = ($currYear-1).'-'.$currYear;
	} else {
		$currSchoolYear = $currYear.'-'.($currYear+1);
	}

	$sql = 
		"SELECT ml.FName, pi.email
		 FROM tbl_masterlist AS ml 
		 LEFT JOIN tbl_personalinformation AS pi 
		 	ON ml.FCode = pi.FCode 
		 WHERE ml.schoolYear = '$currSchoolYear'
		 GROUP BY ml.FCode";

	$result = mysqli_query(conn(),$sql);

	while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$recipients[$row['email']] = $row['FName'];
	}

	if(!empty($recipients)) {
		$mail = new PHPMailer;

		//$mail->isSMTP();   // Uncomment this line on testing server                                  
		$mail->Host = 'ssl://smtp.gmail.com';  
		$mail->SMTPAuth = true;                           
		$mail->Username = 'pupt-fsis@pup-taguig.net';                
		$mail->Password = 'puptfsis';                          
		$mail->SMTPSecure = 'ssl';                            
		$mail->Port = 465;                                

		$mail->setFrom('pupt-fsis@pup-taguig.net', 'PUPT-FSIS');

		foreach ($recipients as $email => $name) {
			$mail->addAddress($email, $name);     
		}

		$mail->isHTML(true);                                  

		$mail->Subject = $subject;
		$mail->Body    = $message;
		$mail->AltBody = 'To view the message, please use an HTML compatible email viewer.';

		if(!$mail->send()) {
			header("location: index.php?r=administrator/other&msg=Message could not be sent.&msgType=error");
		} else {
			header("location: index.php?r=administrator/other&msg=Message has been sent.&msgType=succ");
		}
	} else {
		header("location: index.php?r=administrator/other&msg=Message could not be sent. There are no active faculty and staff listed for the current year.&msgType=error");
	}