<?php
	session_start();
	include_once ("config.php");
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	$cat = $_POST['cat'];
	$ccode = $_POST['ccode'];
	$cdesc = $_POST['cdesc'];
	$sem = $_POST['sem'];
	$sy = $_POST['sy'];
	$sql="Update tbl_subjects set Category = '$cat' where SubjCode = '$ccode'";
	$result=mysqli_query(conn(),$sql);
	if($result) {
		header("Location: index.php?r=administrator/categorizeSubjects");
	}
	mysqli_close(conn());
?>