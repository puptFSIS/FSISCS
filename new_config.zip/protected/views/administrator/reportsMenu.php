<li>
<a href='index.php?r=administrator/checklist'>Checklist</a>
<span class=widget-hint><a href='index.php?r=administrator/printChecklist' target="_blank">Print</a></span>
</li>
<li>
<a href='index.php?r=administrator/InfoReport'>Contact & Birth Date Info</a>
<span class=widget-hint><a href='index.php?r=administrator/PrintInfoReport' target="_blank">Print</a></span>
</li>
<li>
<a href='index.php?r=administrator/fwe'>Work Experience</a>
<span class=widget-hint><a href='index.php?r=administrator/report&content=FWE' target="_blank">Print</a></span>
</li>
<li>
<a href='index.php?r=administrator/fas'>Faculty Attendance in Seminar</a>
<span class=widget-hint><a href='index.php?r=administrator/report&content=FAS' target="_blank">Print</a></span>
</li>
<!--<li>
<a href='index.php?r=administrator/fegs'>Faculty Enrolled in Graduate Studies</a>
<span class=widget-hint><a href='index.php?r=administrator/report&content=FEGS' target="_blank">Print</a></span>
</li>-->
<li>
<a href='index.php?r=administrator/fompo'>Faculty Off/Mem in Professional Org</a>
<span class=widget-hint><a href='index.php?r=administrator/report&content=FOMPO' target="_blank">Print</a></span>
</li>
<li>
<a href='index.php?r=administrator/fs'>Faculty Scholarships</a>
<span class=widget-hint><a href='index.php?r=administrator/report&content=FS' target="_blank">Print</a></span>
</li>
<li>
<a href='index.php?r=administrator/frp'>Faculty Refereed Publications</a>
<span class=widget-hint><a href='index.php?r=administrator/report&content=FRP' target="_blank">Print</a></span>
</li>
<li>
<a href='index.php?r=administrator/gep'>Government Examination Passed</a>
<span class=widget-hint><a href='index.php?r=administrator/report&content=GEP' target="_blank">Print</a></span>
</li>



