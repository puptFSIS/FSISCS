<?php
	session_start();
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	
	
	$sday = $_POST['sday'];
	$stimeS = $_POST['timeS'];
	$stimeE = $_POST['timeE'];
	$profName = $_POST['profName'];
	$sem = $_POST['sem'];
	$sy = $_POST['sy'];
	$valid = checkPrefSched($sday, $stimeS, $stimeE, $profName);
	if($valid)
	{
			$sql = "INSERT INTO tbl_timepreferences (sday, stimeS, stimeE, sprof, sem, schoolYear) VALUES ('$sday','$stimeS','$stimeE','$profName','$sem','$sy')";
			$result = mysqli_query(conn(),$sql);
			if($result)
			{
			
			echo"
			<script>
			window.location.replace('index.php?r=administrator/AddTimePrefer');
			alert('Preferred time schedule added!');
			</script>";
			mysqli_close(conn());
			}
		
	}
	else
	{
		echo"
			<script>
			window.location.replace('index.php?r=administrator/AddTimePrefer');
			alert('Invalid Data!');
			</script>";
			mysqli_close(conn());	
	}
	
	function checkPrefSched($day, $timein, $timeout, $fcode)
	{
		$sem = $_POST['sem'];
		$sy = $_POST['sy'];
		$day = $_POST['sday'];
		$timeS = $_POST['timeS'];
		$timeE = $_POST['timeE'];
		$profName = $_POST['profName'];
		$sql = "SELECT * FROM tbl_timepreferences WHERE sem='$sem' and schoolYear='$sy' and sprof = '$fcode'";
		$result = mysqli_query(conn(),$sql);
		$valid = true;
		while($row=mysqli_fetch_array($result)) 
		{	
			
			if($day == $row['sday'] OR $timein > $timeout OR $timein == $timeout or is_null($day) OR is_null($timein) or is_null($timeout))
			{
				$valid = false;
			}
			else
				$valid = true;
			
		}
		return $valid;
	}

?>
