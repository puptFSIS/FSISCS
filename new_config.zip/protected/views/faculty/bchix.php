<section class='title-right portfolio-filter'>
<!--<a class=home data-category=design href='http://www.puptaguig.net'>Home</a>-->
<a  data-category=all href="index.php?r=faculty/">Profile</a>
<a data-category=design href="index.php?r=faculty/ServiceCredit">Service Credit</a>
<a data-category=design href="index.php?r=faculty/TeachingLoad">Schedule</a>
<a data-category=design href="index.php?r=faculty/logout">Log out</a>
</section>
