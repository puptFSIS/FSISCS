

<li>
<a href='index.php?r=administrator/CourseManagement' >Course Management</a>
</li>
<li>
<a href='index.php?r=administrator/RequestsManagement' >Requested Changes</a>
</li>
<li>
<a href='index.php?r=administrator/SubjectManagement' >Subject Management</a>
</li>

<li>
<a href='index.php?r=administrator/RoomManagement' >Room Management</a>
</li>

<li>
<a href='index.php?r=administrator/CurriculumList' >Curriculum Management</a>
</li>

<li>
<a href='index.php?r=administrator/SchedulingPage' >Schedule Management</a>
</li>

<li>
<a href='index.php?r=administrator/PreScheduling' >PreScheduling</a>
</li>


<li>
<a href='index.php?r=administrator/Categories' >Category Management</a>
</li>

<li>
<a href='index.php?r=administrator/categorizeSubjects' >Categorize Subjects</a>
</li>

<li>
<a href='index.php?r=administrator/TeachingLoad' >Teaching Load</a>
</li>

<li>
<a href='index.php?r=administrator/RoomControl' >Room Control</a>
</li>

<li>
<a href='index.php?r=administrator/profSched' >Faculty Daily Schedule</a>
</li>

<li>
<a href='index.php?r=administrator/studSched' >Student Daily Schedule</a>
</li>

<li>
<a href='index.php?r=administrator/DailySched' >Subjects Daily Schedule</a>
</li>

<li>
<a href='index.php?r=administrator/RoomDailySched' >Room Daily Schedule</a>
</li>







