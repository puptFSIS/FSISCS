<?php
session_start();
if(isset($_SESSION['user'])) {
	if($_SESSION['user']==1) {

	} else if($_SESSION['user']==0) {
		header("location:index.php?r=faculty/");
	}
} else {
	header("location:index.php?r=site/");
}
?>
<!DOCTYPE html>
<!--[if IE 7 ]> <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]> <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]> <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]> <!--> <html class=no-js lang=en> <!-- <![endif]-->
<head>

<!--[if IE ]> <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /> <![endif]-->
<meta content='width=device-width, initial-scale=1.0' name=viewport />
<meta content='FSIS' name=keywords />
<meta content='PUP Taguig FSIS' name=description />
<meta content='vCore Team' name=author />
<!-- Page title -->
<title>Reports | Home</title>
<!-- Page icon -->
<link href='puplogo.ico' rel='shortcut icon'/>
<!-- Stylesheets -->
<style media=screen type='text/css'>@import "styles/base.css";
.cssLT #ut, .cssUT #ut{filter:progid:DXImageTransform.Microsoft.DropShadow(enabled=false);}
.cssWLGradientIMG{BACKGROUND-IMAGE: none;top:0;height:103px;background-color:#ffffff;}
.cssWLGradientIMGSSL{BACKGROUND-IMAGE: none;top:0;height:103px;background-color:#ffffff;}
.cssWLGradientIMG
{BACKGROUND-IMAGE: url(images/hd.jpg);BACKGROUND-REPEAT:repeat-x;top:0;height:105px;}</style>

<link href='styles/print.css' media=print rel=stylesheet />
<!-- Modernizr library -->
<script src='scripts/libs/modernizr/modernizr.min.js'></script>
<meta charset="UTF-8"></head>
<body class='page-media page-sidebar-right'>
<!-- JS notice - will be displayed if javascript is disabled -->
<p id=jsnotice>Javascript is currently disabled. This site requires Javascript to function correctly. Please <a href="http://enable-javascript.com/">enable Javascript in your browser</a>!</p>
<!-- End - JS notice -->
<!-- Page header -->
<div id="GradientDiv" class="cssWLGradientCommon cssWLGradientIMG"></div>

<!-- End - Page header -->

<!-- Page subheader -->

<!-- End - Page subheader -->
<!-- Page body -->
<section class=container-block id=page-body>
<div class=container-inner>
<!-- Page title -->
<header class=container-aligner id=page-title>
<!-- Title and summary -->

<!-- End - Title and summary -->
<!-- Title right side -->
<section class='title-right portfolio-filter'>
<a data-category=design href='http://www.pup-taguig.net'>Home</a>
<a data-category=all href="index.php?r=administrator/profile">Profile</a>
<a data-category=design href="index.php?r=administrator/faculty">Faculty</a>
<a class=current-cat data-category=design href="index.php?r=administrator/reports">Reports</a>
<a data-category=design href="index.php?r=administrator/forms">Forms</a>
<a data-category=design href="index.php?r=administrator/ServiceCreditMenu">Service Credit</a>
<a data-category=design href="index.php?r=administrator/SchedulingSystem">Scheduling</a>
<a data-category=design href="index.php?r=administrator/other">Other</a>
<a data-category=design href="index.php?r=administrator/logout">Log out</a>
</section>
<!-- End - Title right side -->
</header>
<!-- End - Page title -->
<!-- Page body content -->
<section id=page-body-content>
<div id=page-body-content-inner>
<!-- Page content -->
<div id=page-content>
<!-- Video - HTML5 -->
<section>
<h2 class=underlined-header>Reports Coverage</h2>
<?php
	if(isset($_GET['msg'])) {
	$msg = $_GET['msg'];
		if(isset($_GET['msgType'])) {
			if($_GET['msgType']=="err") {
				echo '
				<div class="box-error">
				  <div class="box-content">
					<p>' . $msg . '!</p>
				  </div>
				</div>
				<br />
				<hr style="margin-top:-5px;"/>
				';
			} else {
				echo '
				<div class="box-info">
				  <div class="box-content">
					<p>' . $msg . '!</p>
				  </div>
				</div>
				<br />
				<hr style="margin-top:-5px;"/>
				';
			}
		}
	} else {
	
	}
?>
<?php
	include_once("getReportCoverage.php");
	//<h3 class=underlined-header>Faculty Attendance in Seminar</h3>
?>
<form name="FAScov" action="index.php?r=administrator/saveCoverage" method="POST">
	<?php
		$currYear=date("Y");
	?>
	From: <select name="fromMonth" style="width: 20%">
	<?php
		$sql = "select fromMonth from tbl_reportcoverage where report = 'FAS'";
		$result = mysqli_query(conn(),$sql);
		$row = mysqli_fetch_array($result);
		echo'<option value = "'.$row['fromMonth'].'">'. getMonth($row['fromMonth']) .'</option>';
		echo '<option value="'. 1 .'">'. "JANUARY" .'</option>';
		echo '<option value="'. 2 .'">'. "FEBRUARY" .'</option>';
		echo '<option value="'. 3 .'">'. "MARCH" .'</option>';
		echo '<option value="'. 4 .'">'. "APRIL" .'</option>';
		echo '<option value="'. 5 .'">'. "MAY" .'</option>';
		echo '<option value="'. 6 .'">'. "JUNE" .'</option>';
		echo '<option value="'. 7 .'">'. "JULY" .'</option>';
		echo '<option value="'. 8 .'">'. "AUGUST" .'</option>';
		echo '<option value="'. 9 .'">'. "SEPTEMBER" .'</option>';
		echo '<option value="'. 10 .'">'. "OCTOBER" .'</option>';
		echo '<option value="'. 11 .'">'. "NOVEMBER" .'</option>';
		echo '<option value="'. 12 .'">'. "DECEMBER" .'</option>';
	?>
	</select>
	<select name="fromFAS" style="width: 20%">
	<?php
	for($year=1950;$year<=$currYear;$year++) {
		if($year==$FASfrom) {
			echo '<option value="'. $year .'" selected="selected">'. $year .'</option>';
		} else {
			echo '<option value="'. $year .'">'. $year .'</option>';
		}
	}
	?>
	</select>
	<p style="margin-top: -93px; margin-left: 150px;">To: 
	<select name="toMonth" style="width: 27%">
	<?php
		$sql = "select toMonth from tbl_reportcoverage where report = 'FAS'";
		$result = mysqli_query(conn(),$sql);
		$row = mysqli_fetch_array($result);
		echo'<option value = "'.$row['toMonth'].'">'. getMonth($row['toMonth']) .'</option>';
		echo '<option value="'. 1 .'">'. "JANUARY" .'</option>';
		echo '<option value="'. 2 .'">'. "FEBRUARY" .'</option>';
		echo '<option value="'. 3 .'">'. "MARCH" .'</option>';
		echo '<option value="'. 4 .'">'. "APRIL" .'</option>';
		echo '<option value="'. 5 .'">'. "MAY" .'</option>';
		echo '<option value="'. 6 .'">'. "JUNE" .'</option>';
		echo '<option value="'. 7 .'">'. "JULY" .'</option>';
		echo '<option value="'. 8 .'">'. "AUGUST" .'</option>';
		echo '<option value="'. 9 .'">'. "SEPTEMBER" .'</option>';
		echo '<option value="'. 10 .'">'. "OCTOBER" .'</option>';
		echo '<option value="'. 11 .'">'. "NOVEMBER" .'</option>';
		echo '<option value="'. 12 .'">'. "DECEMBER" .'</option>';

	?>
	</select>
	<select name="toFAS" style="width: 27%;">
	<?php
	
	for($year=1950;$year<=$currYear;$year++) {
		if($year==$FASto) {
			echo '<option value="'. $year .'" selected="selected">'. $year .'</option>';
		} else {
			echo '<option value="'. $year .'">'. $year .'</option>';
		}
	}
	?>
	</select></p>
	<input type="hidden" name="reportCat" value="FAS" />
	<input type="submit" name="submit" value="Save">
	<p />
</form>
<!--
<form name="WEcov" action="index.php?r=administrator/saveCoverage" method="POST">
<h3 class=underlined-header>Work Experience</h3>
<p>From: <select name="fromWE" style="width: 15%">
<?php
for($year=1950;$year<=$currYear;$year++) {
	if($year==$WEfrom) {
		echo '<option value="'. $year .'" selected="selected">'. $year .'</option>';
	} else {
		echo '<option value="'. $year .'">'. $year .'</option>';
	}
}
?>
</select></p>
<p style="margin-top: -77px; margin-left: 100px;">To: <select name="toWE" style="width: 15%">
<?php
for($year=1950;$year<=$currYear;$year++) {
	if($year==$WEto) {
		echo '<option value="'. $year .'" selected="selected">'. $year .'</option>';
	} else {
		echo '<option value="'. $year .'">'. $year .'</option>';
	}
}
?>
</select></p>
<input type="hidden" name="reportCat" value="WE" />
<input type="submit" name="submit" value="Save">
<p />
</form>

<form name="VWcov" action="index.php?r=administrator/saveCoverage" method="POST">
<h3 class=underlined-header>Voluntary Works</h3>
<p>From: <select name="fromVW" style="width: 15%">
<?php
for($year=1950;$year<=$currYear;$year++) {
	if($year==$VWfrom) {
		echo '<option value="'. $year .'" selected="selected">'. $year .'</option>';
	} else {
		echo '<option value="'. $year .'">'. $year .'</option>';
	}
}
?>
</select></p>
<p style="margin-top: -77px; margin-left: 100px;">To: <select name="toVW" style="width: 15%">
<?php
for($year=1950;$year<=$currYear;$year++) {
	if($year==$VWto) {
		echo '<option value="'. $year .'" selected="selected">'. $year .'</option>';
	} else {
		echo '<option value="'. $year .'">'. $year .'</option>';
	}
}
?>

<?php
	function getMonth($m){
		if($m == 1)
			return "JANUARY";
		elseif($m == 2)
			return "FEBRUARY";
		elseif($m == 3)
			return "MARCH";
		elseif($m == 4)
			return "APRIL";
		elseif($m == 5)
			return "MAY";
		elseif($m == 6)
			return "JUNE";
		elseif($m == 7)
			return "JULY";
		elseif($m == 8)
			return "AUGUST";
		elseif($m == 9)
			return "SEPTEMBER";
		elseif($m == 10)
			return "OCTOBER";
		elseif($m == 11)
			return "NOVEMBER";
		elseif($m == 12)
			return "DECEMBER";
	}
?>
</select></p>
<input type="hidden" name="reportCat" value="VW" />
<input type="submit" name="submit" value="Save">
<p />
</form>
-->
</section>
<!-- End - Showcase gallery -->
</div>
<!-- End - Page content -->
<!-- Page sidebar -->
<aside class=page-sidebar>
<section class='widget-container widget-categories'>
<h2 class=widget-heading>Faculty Reports</h2>
<div class=widget-content>
<ul class='widget-list categories-list'>

<?php include_once("reportsMenu.php");?>

</ul>
</div>
</section>
</aside>
<!-- End - Page sidebar -->
</div>
</section>
<!-- End - Page body content -->
</div>
</section>
<!-- End - Page body -->

<!-- Page footer -->
<footer id=page-footer>
<div class=container-aligner>
<!-- Footer left -->
<section id=footer-left>
� Copyright 2011 <a href="#" title="Dbooom Themes">vCore Team | PUP Taguig</a> - All Rights Reserved.
</section>
<!-- End - Footer left -->
<!-- Footer right -->
<section id=footer-right>
<ul class=footer-navigation>
<li>
<a href='http://www.pup-taguig.net' title=Home>Home</a>
</li>
<li>
<a href='index.php?r=site/about' title=About>About</a>
</li>
<li>
<a href='index.php?r=site/contact' title=Contacts>Contacts</a>
</li>
</ul>
</section>
<!-- End - Footer right -->
</div>
</footer>
<!-- End - Page footer -->
<!-- Theme backgrounds -->
<div id=theme-backgrounds>

<img alt='Asset 4' data-color='#D64333' src='assets/backgrounds/4.jpg.pagespeed.ce.AV4Gchw-qN.jpg' width=1600 height=1064 />

</div>
<!-- End - Theme backgrounds -->
<link href='scripts/libs/switcher/switcher.css' rel=stylesheet />

<!-- Scripts -->
<script id=js-dispatcher src='scripts/scripts.js'></script>
</body>
</html>