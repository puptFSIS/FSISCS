<?php
session_start();
unset($_SESSION['user']);
unset($_SESSION['CEmpID']);
unset($_SESSION['userID']);
header("location:index.php");
?>