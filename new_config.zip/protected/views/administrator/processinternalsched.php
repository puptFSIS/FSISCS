<?php
	session_start();
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	$request_id = $_GET['request_id'];
	$schedID = $_GET['schedID'];

	$sql1 = "SELECT * FROM tbl_requestschedule WHERE request_id= '$request_id' and schedID= '$schedID' and status='Pending'";
	$result1 = mysqli_query(conn(),$sql1);
while($row = mysqli_fetch_array($result1)) 
						{
	$request_id = $row['request_id'];
					$schedID = $row['schedID'];
					$currID = $row['currID'];
					$courseID = $row['courseID'];
					$csection = $row['csection'];
					$cyear = $row['cyear'];
					$scode = $row['scode'];
					$stitle = $row['stitle'];
					$units = $row['units'];
					$lec = $row['lec'];
					$lab = $row['lab'];
					$sday = $row['sday'];
					$stimeS = $row['stimeS'];
					$stimeE = $row['stimeE'];
					$sroom = $row['sroom'];
					$sprof = $row['sprof'];
					$sem = $row['sem'];
					$schoolYear = $row['schoolYear'];
				
	if($result1)
	{

		$count=mysqli_num_rows($result1);
			if($count>0){
				$sql="UPDATE tbl_requestschedule SET  status='Approved' , datemodified=NOW() where request_id='$request_id' and schedID = '$schedID'";
				$sql2="UPDATE tbl_internaschedule SET sday='$sday', stimeS='$stimeS', stimeE='$stimeE', sroom='$sroom' where schedID='$schedID'";
					# sday2 = '$day2', stimeS2 = '$timeS2', stimeE2 = '$timeE2', sroom2 = '$roomName2'
				$result=mysqli_query(conn(),$sql);
				$result2=mysqli_query(conn(),$sql2);
			
			}
				header("Location: index.php?r=administrator/RequestsManagement");
					mysqli_close(conn());
				}
				else
		{
		echo"
			<script>
			window.location.replace('index.php?r=administrator/RequestsManagement');
			alert('Something went wrong');
			</script>";
			mysqli_close(conn());	
		}
	}
	

?>
