<?php
	session_start();
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	$sy = $_GET['sy'];
	$currID = $_GET['currID'];
	$courseID = $_GET['courseID'];
	$scode = $_GET['scode'];
	$cYear = $_GET['year'];
	$sy = $_GET['sy'];
	$sql="DELETE FROM tbl_curriculum WHERE currID='$currID' AND courseID='$courseID' AND scode='$scode' AND schoolYear = '$sy'";
	$sql2="DELETE FROM tbl_schedule WHERE currID='$currID' AND courseID='$courseID' AND scode='$scode' AND schoolYear = '$sy'";
	$result=mysqli_query(conn(),$sql);
	$result2=mysqli_query(conn(),$sql2);
	if($result AND $result2) {
		header("Location: index.php?r=administrator/ViewCurriculum/&courseID=$courseID&year=$cYear&currID=$currID&sy=$sy");
	}
	mysqli_close(conn());
?>