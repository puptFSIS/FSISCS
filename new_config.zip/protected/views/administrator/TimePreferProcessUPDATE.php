<?php
	session_start();
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	
	
	$sday = $_POST['sday'];
	$stimeS = $_POST['timeS'];
	$stimeE = $_POST['timeE'];
	$profName = $_POST['profName'];
	$sem = $_GET['sem'];
	$timeID = $_GET['timeID'];
	$sy = $_GET['sy'];

	$valid = checkPrefSched($sday, $stimeS, $stimeE, $profName);

	if($valid)
	{
			$sql = "UPDATE tbl_timepreferences SET sday='$sday', stimeS='$stimeS', stimeE='$stimeE', sprof='$profName' WHERE timeID='$timeID'";
			$result = mysqli_query(conn(),$sql);
			if($result)
			{
			echo"
			<script>
			window.location.replace('index.php?r=administrator/TimePrefer&sem=1&sy=2015-2016');
			alert('Preferred time schedule added!');
			</script>";
			mysqli_close(conn());
			}		
	}
	else
	{
		echo"
			<script>
			window.location.replace('index.php?r=administrator/TimePrefer&sem=1&sy=2015-2016&timeID=". $timeID ."');
			alert('Invalid Data!');
			</script>";
			mysqli_close(conn());	
	}
	
	function checkPrefSched($day, $timein, $timeout, $fcode)
	{
		$sem = $_GET['sem'];
		$sy = $_GET['sy'];
		$day = $_POST['sday'];
		$timeS = $_POST['timeS'];
		$timeE = $_POST['timeE'];
		$profName = $_POST['profName'];
		$sql = "SELECT * FROM tbl_timepreferences WHERE sem='$sem' and schoolYear='$sy' and sprof = '$fcode'";
		$result = mysqli_query(conn(),$sql);
		$valid = true;
		while($row=mysqli_fetch_array($result)) 
		{	
			
			if($timein > $timeout OR $timein == $timeout or is_null($day) OR is_null($timein) or is_null($timeout))
			{
				$valid = false;
			}
			else
				$valid	 = true;
			
		}
		return $valid;
	}

?>
