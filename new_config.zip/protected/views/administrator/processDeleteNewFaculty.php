<?php
$name = $_GET['Name'];
header("location:NewFaculty.php?msg=del");
echo "BUG DOWN";
?>