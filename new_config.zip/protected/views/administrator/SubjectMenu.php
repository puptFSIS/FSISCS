

<li>
<a href='index.php?r=administrator/SubjPreferALL' >Preferred Subjects & Schedule</a>
</li>

<li>
<a href='index.php?r=administrator/tagSubjects' >Tag Subjects</a>
</li>

<li>
<a href='index.php?r=administrator/TagSchedules' >Manage Subjects</a>
</li>


<li>
<a href='index.php?r=administrator/AddTimePrefer' >Add Schedule</a>
</li>

<li>
<a href='index.php?r=administrator/TimePrefer' >Manage Schedules</a>
</li>




