<?php
	header("Location: index.php?r=administrator/");
?>