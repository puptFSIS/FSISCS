<?php
	session_start();
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	$ccode = $_POST['scode'];
	$ctitle = $_POST['stitle'];
	$oldSubj = $_POST['oldsubj'];
	$lec = $_POST['lec'];
	$lab = $_POST['lab'];
	$sql="UPDATE tbl_subjects SET SubjCode = '$ccode', SubjDescription = '$ctitle', HoursLec = '$lec', HoursLab = '$lab' WHERE SubjCode = '$oldSubj'";
	$result=mysqli_query(conn(),$sql);
	if($result) {
		header("Location: index.php?r=administrator/SubjectManagement");
	}
	mysqli_close(conn());
?>
