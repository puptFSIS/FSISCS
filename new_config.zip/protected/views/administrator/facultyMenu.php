<ul class='widget-list categories-list'>
<li>
<a href='index.php?r=administrator/nfa' >New Account</a>
</li>
<li>
<a href='index.php?r=administrator/lfa' >List of Faculty Accounts</a>
</li>
<li>
<a href='index.php?r=administrator/NewFaculty' >New Faculty Members</a>
</li>
<li>
<a href='index.php?r=administrator/BranchOfficials' >Branch Officials</a>
</li>
<li>
<a href='index.php?r=administrator/AdminStaff' >Administrative Staff</a>
</li>
<li>
<a href='index.php?r=administrator/FullTime' >Full Time Faculty</a>
</li>
<li>
<a href='index.php?r=administrator/PartTime' >Part Time Faculty</a>
</li>
<li>
<a href='index.php?r=administrator/SecurityGuard' >Security Guards</a>
</li>
</ul>

