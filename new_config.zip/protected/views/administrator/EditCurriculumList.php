<?php
	session_start();
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	$currID = $_GET['currID'];
	$sy = $_GET['sy'];
	$course = $_GET['course'];
	$sql="DELETE FROM tbl_curriculumlist WHERE currID = '$currID' AND currDesc = '$sy' AND courseDesc = '$course'";
	$result = mysqli_query(conn(),$sql);
	if($result){
		header("Location: index.php?r=administrator/CurriculumList");
	}
	mysqli_close(conn());
?>