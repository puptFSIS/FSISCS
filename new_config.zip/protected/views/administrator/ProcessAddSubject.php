<?php
	session_start();
	$EmpID = $_SESSION['CEmpID']; 
	include_once("config.php");
	$ccode = $_POST['scode'];
	$ctitle = $_POST['stitle'];
	$lec = $_POST['lec'];
	$lab = $_POST['lab'];
	$sql = "SELECT * FROM tbl_subjects WHERE SubjCode = '$ccode'";
	$result = mysqli_query(conn(),$sql);
	$count = mysqli_num_rows($result);
	if ($count > 1) 
	{
	header("Location: index.php?r=administrator/SubjectManagement");
	}
	else
	{
		$sql="INSERT INTO tbl_subjects (SubjCode,SubjDescription,HoursLec,HoursLab) VALUES ('$ccode','$ctitle','$lec','$lab')";
		$result=mysqli_query(conn(),$sql);
		header("Location: index.php?r=administrator/SubjectManagement");
	}

	mysqli_close(conn());
?>