<?php
	$test = 0;

	if($test==1) {
		$host="localhost"; 
		$username="puptagui_bsit217"; 
		$password="bsit217";
		$database="puptagui_db_puptaguig2";
		error_reporting(E_ALL ^ E_DEPRECATED);
	} else {
		$host="localhost"; 
		$username="root"; 
		$password=""; 
		$database="db_puptaguig2";
	}

	define('HOST', $host);
	define('USERNAME', $username);
	define('PASSWORD', $password);
	define('DATABASE', $database);

	function conn() {
		static $conn;

		if ($conn===NULL){ 
	        $conn = mysqli_connect(HOST, USERNAME, PASSWORD, DATABASE) or die("cannot connect"); 
	    }

	    return $conn;
	}
?>