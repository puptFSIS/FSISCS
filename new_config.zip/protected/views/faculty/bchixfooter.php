<div class=container-aligner>
<!-- Footer left -->
<section id=footer-left>
Copyright 2014 <a href="#" title="Dbooom Themes">BCHIX DEVELOPMENT Team | PUP Taguig</a> - All Rights Reserved.
</section>
<!-- End - Footer left -->
<!-- Footer right -->

<section id=footer-right>
<ul class=footer-navigation>
<li>
<a href='http://www.pup-taguig.net' title=Home>Home</a>
</li>
<!--
<li>
<a href='index.php?r=site/about' title=About>About</a>
</li>
<li>
<a href='index.php?r=site/contact' title=Contacts>Contacts</a>
</li>
-->
</ul>
</section>
<!-- End - Footer right -->
</div>