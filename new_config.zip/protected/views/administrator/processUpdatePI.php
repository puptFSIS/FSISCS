<?php
	include_once("config.php");
	session_start();
	$surname = $_POST['surname'];
	$firstname = $_POST['firstname'];
	$middlename = $_POST['middlename'];
	$nameextension = $_POST['nameextension'];
	$bmonth = $_POST['bmonth'];
	$bday = $_POST['bday'];
	$byear = $_POST['byear'];

	$birthplace = $_POST['birthplace'];
	$gender = $_POST['gender'];
	$civilstatus = $_POST['cs'];
	$citizenship = $_POST['citizenship'];
	$height = $_POST['height'];
	$weight= $_POST['weight'];
	$bloodtype = $_POST['bloodtype'];
	$gsis = $_POST['gsis'];
	$pagibig = $_POST['pagibig'];
	$philhealth = $_POST['philhealth'];
	$sss = $_POST['sss'];
	$residentialAdd = $_POST['residentialAddress'];
	$residentialZip = $_POST['zipCode'];
	$residentialTel = $_POST['telNo'];
	$permanentAdd = $_POST['permanentAddress'];
	$permanentZip = $_POST['pzipCode'];
	$permanentTel = $_POST['ptelNo'];
	$email = $_POST['email'];
	$cel = $_POST['cellNo'];
	$tin = $_POST['TIN_NO'];
	$EmpNo = $_POST['agencyempno'];
	$EmpID = $_SESSION['CEmpID'];
	//$_SESSION['Fcode'] = $_POST['username'];
	$UserID = $_SESSION['FCode'];
	
	$sql="UPDATE tbl_personalinformation SET surname='$surname', firstname='$firstname', middlename='$middlename', nameExtension='$nameextension', bmonth='$bmonth', bday='$bday', byear='$byear', birthplace='$birthplace', sex='$gender', civilStatus='$civilstatus', citizenship='$citizenship', height='$height', weight='$weight', bloodType='$bloodtype', GSIS_ID_NO='$gsis', PAGIBIG_ID_NO='$pagibig', PHILHEALTH_NO='$philhealth', SSS_NO='$sss', TIN_NO='$tin', zipCode='$residentialZip', telNo='$residentialTel', cellNo='$cel', email='$email', residentialAddress='$residentialAdd', permanentAddress='$permanentAdd', pzipCode='$permanentZip', ptelNo='$permanentTel' WHERE EmpID='$EmpID'";
	$result=mysqli_query(conn(),$sql);	
	
	$sql1="UPDATE tbl_evaluationfaculty SET empNumber='$EmpNo' WHERE FCode='$UserID'";
	$result1=mysqli_query(conn(),$sql1);
	
	/*
	$sql2="UPDATE tbl_familybackground SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result2=mysqli_query(conn(),$sql2);
	
	$sql3="UPDATE tbl_children SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result3=mysqli_query(conn(),$sql3);
	
	$sql4="UPDATE tbl_cse SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result4=mysqli_query(conn(),$sql4);

	$sql5="UPDATE tbl_educationalbackground SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result5=mysqli_query(conn(),$sql5);

	$sql6="UPDATE tbl_faculty SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result6=mysqli_query(conn(),$sql6);

	$sql7="UPDATE tbl_familybackground SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result7=mysqli_query(conn(),$sql7);

	$sql8="UPDATE tbl_gov SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result8=mysqli_query(conn(),$sql8);

	$sql9="UPDATE tbl_lastlogin SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result9=mysqli_query(conn(),$sql9);

	$sql10="UPDATE tbl_org SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result10=mysqli_query(conn(),$sql10);

	$sql11="UPDATE tbl_recognition SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result11=mysqli_query(conn(),$sql11);

	$sql12="UPDATE tbl_referred SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result12=mysqli_query(conn(),$sql12);

	$sql13="UPDATE tbl_scholar SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result13=mysqli_query(conn(),$sql13);

	$sql14="UPDATE tbl_seminar SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result14=mysqli_query(conn(),$sql14);

	/*$sql15="UPDATE tbl_snc SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result15=mysqli_query(conn(),$sql15);*/

	/*
	$sql16="UPDATE tbl_workexperience SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result16=mysqli_query(conn(),$sql16);
	
	$sql17="UPDATE tbl_vwork SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result17=mysqli_query(conn(),$sql17);
	
	$sql18="UPDATE tbl_tprograms SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result18=mysqli_query(conn(),$sql18);
	
	$sql19="UPDATE tbl_skh SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result19=mysqli_query(conn(),$sql19);
	
	$sql20="UPDATE tbl_nadr SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result20=mysqli_query(conn(),$sql20);
	
	$sql21="UPDATE tbl_miao SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result21=mysqli_query(conn(),$sql21);
	
	$sql22="UPDATE tbl_qa SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result22=mysqli_query(conn(),$sql22);
	
	$sql23="UPDATE tbl_references SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result23=mysqli_query(conn(),$sql23);
	
	$sql24="UPDATE tbl_taxcertificate SET EmpID='$EmpNo' WHERE EmpID='$EmpID'";
	$result24=mysqli_query(conn(),$sql24);
	*/
	
	if($result) {
		//$_SESSION['CEmpID'] = $EmpNo;
		header("Location: index.php?r=administrator/pi&msg=Your profile has been updated successfully!&msgType=succ");
	} else {
		header("Location: index.php?r=administrator/pi&msg=Error saving personal information.&msgType=err");
	}
?>