<?php
session_start();
if(isset($_SESSION['user'])) {
	if($_SESSION['user']==1) {

	} else if($_SESSION['user']==0) {

	}
} else {
	header("location:index.php?r=site/");
}
?>
<!DOCTYPE html>
<!--[if IE 7 ]> <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]> <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]> <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]> <!--> <html class=no-js lang=en> <!-- <![endif]-->
<head>

<!--[if IE ]> <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" /> <![endif]-->
<meta content='width=device-width, initial-scale=1.0' name=viewport />
<meta content='FSIS' name=keywords />
<meta content='PUP Taguig FSIS' name=description />
<meta content='vCore Team' name=author />
<!-- Page title -->
<title>Faculty | Home</title>
<!-- Page icon -->
<link href='puplogo.ico' rel='shortcut icon'/>
<!-- Stylesheets -->
<style media=screen type='text/css'>@import "styles/base.css";
.cssLT #ut, .cssUT #ut{filter:progid:DXImageTransform.Microsoft.DropShadow(enabled=false);}
.cssWLGradientIMG{BACKGROUND-IMAGE: none;top:0;height:103px;background-color:#ffffff;}
.cssWLGradientIMGSSL{BACKGROUND-IMAGE: none;top:0;height:103px;background-color:#ffffff;}
.cssWLGradientIMG
{BACKGROUND-IMAGE: url(images/hd.jpg);BACKGROUND-REPEAT:repeat-x;top:0;height:105px;}</style>

<link href='styles/print.css' media=print rel=stylesheet />
<!-- Modernizr library -->
<script src='scripts/libs/modernizr/modernizr.min.js'></script>
<meta charset="UTF-8"></head>
<body class='page-media page-sidebar-right'>
<!-- JS notice - will be displayed if javascript is disabled -->
<p id=jsnotice>Javascript is currently disabled. This site requires Javascript to function correctly. Please <a href="http://enable-javascript.com/">enable Javascript in your browser</a>!</p>
<!-- End - JS notice -->
<!-- Page header -->
<div id="GradientDiv" class="cssWLGradientCommon cssWLGradientIMG"></div>

<!-- End - Page header -->

<!-- Page subheader -->

<!-- End - Page subheader -->
<!-- Page body -->
<section class=container-block id=page-body>
<div class=container-inner>
<!-- Page title -->
<header class=container-aligner id=page-title>
<!-- Title and summary -->

<!-- End - Title and summary -->
<!-- Title right side -->
<section class='title-right portfolio-filter'>
<a data-category=design href='http://www.pup-taguig.net'>Home</a>
<a class=current-cat data-category=all href="index.php?r=administrator/profile">Profile</a>
<a data-category=design href="index.php?r=administrator/faculty">Faculty</a>
<a data-category=design href="index.php?r=administrator/reports">Reports</a>
<a data-category=design href="index.php?r=administrator/forms">Forms</a>
<a data-category=design href="index.php?r=administrator/ServiceCreditMenu">Service Credit</a>
<a data-category=design href="index.php?r=administrator/SchedulingSystem">Scheduling</a>
<a data-category=design href="index.php?r=administrator/SubjPrefer">Subject Preferences</a>
<a data-category=design href="index.php?r=administrator/other">Other</a>
<a data-category=design href="index.php?r=administrator/logout">Log out</a>
</section>
<!-- End - Title right side -->
</header>
<!-- End - Page title -->
<!-- Page body content -->
<section id=page-body-content>
<div id=page-body-content-inner>
<!-- Page content -->
<div id=page-content>
<!-- Video - HTML5 -->
<section>

<h2 class=underlined-header>Getting Started with Your Account</h2>

<div class=align-left>
<div class=element-holder>
<img alt='Image example' src='assets/personalInfo.jpg' width=220 />
<div class=caption>Personal Information</div>
</div>
</div>
<p><h4>Personal Information</h4>View your personal information such as Employee ID, Full Name, Citizenship, Government Card Nos, Residential and Permanent Address, and Contact Details. You can update your personal information by clicking the update button in the right sidebar or in the top of the personal information page.</p>
<hr />

<div class=align-right>
<div class=element-holder>
<img alt='Image example' src='assets/familyBckg.jpg' width=220 />
<div class=caption>Family Background</div>
</div>
</div>
<p><h4>Family Background</h4>View your mother's and father's basic information such as their full name and their siblings with its birthdate. You can update your family background by clicking the update button in the right sidebar or the update button in family background page. You can add your sibling by clicking the "Add Chil/Children".</p>
<hr />

<div class=align-left>
<div class=element-holder>
<img alt='Image example' src='assets/educBckg.jpg' width=220 />
<div class=caption>Educational Background</div>
</div>
</div>
<p><h4>Educational Background</h4>View and update your educational background from elementary to college to masteral and doctorate. You can add one (1) school for elementary and high school level, and you can add all of the schools that you had been graduated in vocation, college, masteral and doctorate level. </p>
<hr />

<div class=align-right>
<div class=element-holder>
<img alt='Image example' src='assets/workExp.jpg' width=220 />
<div class=caption>Work Experience</div>
</div>
</div>
<p><h4>Work Experience</h4>You can view and update your work experience by clicking the "Work Experience" in the right sidebar. You are required to input the name of the company, your position, inclusive date/year, salary, salary grade  and step increment, status and will ask you if it is a government service.</p>
<hr />

<div class=align-left>
<div class=element-holder>
<img alt='Image example' src='assets/accSettings.jpg' width=220 />
<div class=caption>Account Settings</div>
</div>
</div>
<p><h4>Account Settings</h4>In this setion, you can change your username, the default username is your employee ID. You can also change your password and security question. To start changing your account settings and information, click "Account Settings" in the right sidebar.</p>
<hr />

</section>
<!-- End - Video -HTML5 -->
<br/>

<!-- End - Showcase gallery -->
</div>
<!-- End - Page content -->
<!-- Page sidebar -->
<aside class=page-sidebar>
<section class='widget-container widget-categories'>
<h2 class=widget-heading>Profile</h2>
<div class=widget-content>
<ul class='widget-list categories-list'>
<?php include_once("profileMenu.php");?>
</ul>
</div>
</section>
</aside>
<!-- End - Page sidebar -->
</div>
</section>
<!-- End - Page body content -->
</div>
</section>
<!-- End - Page body -->

<!-- Page footer -->
<footer id=page-footer>
<div class=container-aligner>
<!-- Footer left -->
<section id=footer-left>
� Copyright 2011 <a href="#" title="Dbooom Themes">vCore Team | PUP Taguig</a> - All Rights Reserved.
</section>
<!-- End - Footer left -->
<!-- Footer right -->
<section id=footer-right>
<ul class=footer-navigation>
<li>
<a href='http://www.pup-taguig.net' title=Home>Home</a>
</li>
<li>
<a href='index.php?r=site/about' title=About>About</a>
</li>
<li>
<a href='index.php?r=site/contact' title=Contacts>Contacts</a>
</li>
</ul>
</section>
<!-- End - Footer right -->
</div>
</footer>
<!-- End - Page footer -->
<!-- Theme backgrounds -->
<div id=theme-backgrounds>

<img alt='Asset 4' data-color='#D64333' src='assets/backgrounds/4.jpg.pagespeed.ce.AV4Gchw-qN.jpg' width=1600 height=1064 />

</div>
<!-- End - Theme backgrounds -->
<link href='scripts/libs/switcher/switcher.css' rel=stylesheet />

<!-- Scripts -->
<script id=js-dispatcher src='scripts/scripts.js'></script>
</body>
</html>

